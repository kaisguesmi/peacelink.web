<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Soumettre une Réclamation - PeaceLink</title>

    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        /* Mini style pour formulaire */
        .form-container {
            max-width: 600px;
            margin: 40px auto;
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0px 2px 12px rgba(0,0,0,0.1);
        }

        .form-container h2 {
            margin-bottom: 15px;
        }

        .form-group {
            margin-bottom: 18px;
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            margin-bottom: 6px;
            font-weight: 600;
        }

        .form-group input, .form-group textarea, .form-group select {
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
            resize: none;
        }

        .btn-submit {
            display: flex;
            align-items: center;
            gap: 8px;
            background: #007bff;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
        }

        .btn-submit:hover {
            background: #0062d0;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            display: none;
        }

        .alert.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            display: block;
        }

        .alert.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            display: block;
        }

        .alert ul {
            margin: 0;
            padding-left: 20px;
        }
    </style>
</head>

<body>

    <!-- Header simple du front -->
    <header class="front-header">
        <h1>PeaceLink</h1>
    </header>

    <!-- Conteneur du formulaire -->
    <div class="form-container">

        <h2><i class="fa-solid fa-circle-exclamation"></i> Soumettre une réclamation</h2>
        <p>Expliquez votre problème, notre équipe vous répondra rapidement.</p>

        <?php
        if (isset($_GET['success']) && $_GET['success'] == 1) {
            echo '<div class="alert success"><i class="fa-solid fa-check"></i> Votre réclamation a été soumise avec succès!</div>';
            unset($_SESSION['message_success']);
        }
        
        if (isset($_GET['error']) && $_GET['error'] == 1) {
            if (isset($_SESSION['erreurs']) && is_array($_SESSION['erreurs'])) {
                echo '<div class="alert error"><i class="fa-solid fa-exclamation"></i> <strong>Erreurs:</strong><ul>';
                foreach ($_SESSION['erreurs'] as $erreur) {
                    echo '<li>' . htmlspecialchars($erreur) . '</li>';
                }
                echo '</ul></div>';
                unset($_SESSION['erreurs']);
            } elseif (isset($_SESSION['message_error'])) {
                echo '<div class="alert error"><i class="fa-solid fa-exclamation"></i> ' . htmlspecialchars($_SESSION['message_error']) . '</div>';
                unset($_SESSION['message_error']);
            }
        }
        ?>

        <form action="traitement_reclamation.php" method="post">

            <!-- Nom utilisateur -->
            <div class="form-group">
                <label>Nom complet</label>
                <input type="text" name="nom" placeholder="Votre nom" required>
            </div>

            <!-- Email -->
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" placeholder="Votre email" required>
            </div>

            <!-- Type de problème -->
            <div class="form-group">
                <label>Type de problème</label>
                <select name="type" required>
                    <option value="">-- Choisir --</option>
                    <option value="story">Problème avec une Story</option>
                    <option value="profil">Erreur dans le profil</option>
                    <option value="messagerie">Problème de messagerie</option>
                    <option value="autre">Autre</option>
                </select>
            </div>

            <!-- Description -->
            <div class="form-group">
                <label>Description du problème</label>
                <textarea name="description" rows="6"
                    placeholder="Décrivez votre problème..." required></textarea>
            </div>

            <!-- Bouton submit -->
            <button type="submit" class="btn-submit">
                <i class="fa-solid fa-paper-plane"></i>
                Envoyer la réclamation
            </button>

        </form>
    </div>

</body>
</html>
