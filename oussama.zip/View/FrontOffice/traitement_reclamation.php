<?php
// traitement_reclamation.php
// Fichier pour traiter les réclamations soumises par les utilisateurs

session_start();

// Configuration
$servername = "localhost";
$username = "root";
$password = "";
$database = "peacelink";

// Créer la connexion
$conn = new mysqli($servername, $username, $password, $database);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Erreur de connexion à la base de données: " . $conn->connect_error);
}

// Vérifier si la requête est POST
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: reclamation_front.php");
    exit();
}

try {
    // Récupérer et nettoyer les données du formulaire (pas de htmlspecialchars ici, seulement trim)
    $nom = isset($_POST['nom']) ? trim($_POST['nom']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $type = isset($_POST['type']) ? trim($_POST['type']) : '';
    $description = isset($_POST['description']) ? trim($_POST['description']) : '';
    $date_creation = date('Y-m-d H:i:s');
    
    // Validation des données
    $erreurs = [];
    
    if (empty($nom) || strlen($nom) < 2) {
        $erreurs[] = "Le nom est requis et doit contenir au moins 2 caractères.";
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erreurs[] = "L'email est invalide.";
    }
    
    if (empty($type)) {
        $erreurs[] = "Le type de problème est requis.";
    }
    
    if (empty($description) || strlen($description) < 10) {
        $erreurs[] = "La description doit contenir au moins 10 caractères.";
    }
    
    // Si erreurs, rediriger
    if (!empty($erreurs)) {
        $_SESSION['erreurs'] = $erreurs;
        header("Location: reclamation_front.php?error=1");
        exit();
    }
    
    // Préparer la requête SQL
    $sql = "INSERT INTO reclamations (nom, email, type, description, date_creation, statut) 
            VALUES (?, ?, ?, ?, ?, 'nouveau')";
    
    $stmt = $conn->prepare($sql);
    
    if ($stmt === false) {
        throw new Exception("Erreur de préparation: " . htmlspecialchars($conn->error));
    }
    
    // Binder les paramètres
    $stmt->bind_param("sssss", $nom, $email, $type, $description, $date_creation);
    
    // Exécuter la requête
    if (!$stmt->execute()) {
        throw new Exception("Erreur lors de l'insertion: " . htmlspecialchars($stmt->error));
    }
    
    $stmt->close();
    header("Location: reclamation_front.php?success=1");
    exit();
    
} catch (Exception $e) {
    $_SESSION['message_error'] = $e->getMessage();
    header("Location: reclamation_front.php?error=1");
    exit();
} finally {
    if (isset($conn)) {
        $conn->close();
    }
}
?>
