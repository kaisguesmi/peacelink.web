<?php
// detail_reclamation.php
// Affiche les détails d'une réclamation

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$database = "peacelink";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Erreur de connexion: " . $conn->connect_error);
}

// Récupérer l'ID de la réclamation
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: gerer_reclamations.php");
    exit();
}

$id = intval($_GET['id']);
$sql = "SELECT * FROM reclamations WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Réclamation non trouvée.";
    exit();
}

$row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails de la réclamation - PeaceLink</title>
    <link rel="stylesheet" href="backofficeStyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .detail-container { max-width: 900px; margin: 0 auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0px 2px 12px rgba(0,0,0,0.1); }
        .detail-field { margin-bottom: 25px; display: flex; flex-direction: column; }
        .detail-label { font-weight: 600; color: #333; margin-bottom: 8px; }
        .detail-value { color: #666; padding: 12px; background: #f5f5f5; border-radius: 8px; }
        .action-buttons { display: flex; gap: 10px; margin-top: 30px; }
        .btn { padding: 10px 20px; border-radius: 8px; cursor: pointer; font-weight: 600; border: none; }
        .btn-primary { background: #5DADE2; color: white; }
        .btn-danger { background: #E74C3C; color: white; }
        .btn-secondary { background: #e9ecef; color: #333; }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <a href="#" class="logo">
                <img src="mon-logo.png" alt="Logo">
                <span>PeaceLink</span>
            </a>
        </div>
        <nav class="sidebar-nav">
            <a href="gerer_reclamations.php" class="nav-item">
                <i class="fa-solid fa-arrow-left"></i>
                <span>Retour aux réclamations</span>
            </a>
        </nav>
    </div>

    <div class="main-content">
        <header class="topbar">
            <h1 style="margin-left:20px;">Détails de la Réclamation #<?php echo htmlspecialchars($row['id']); ?></h1>
        </header>

        <main class="content-wrapper">
            <div class="detail-container">
                <div class="detail-field">
                    <label class="detail-label">ID</label>
                    <div class="detail-value"><?php echo htmlspecialchars($row['id']); ?></div>
                </div>

                <div class="detail-field">
                    <label class="detail-label">Nom du réclamant</label>
                    <div class="detail-value"><?php echo htmlspecialchars($row['nom']); ?></div>
                </div>

                <div class="detail-field">
                    <label class="detail-label">Email</label>
                    <div class="detail-value"><a href="mailto:<?php echo htmlspecialchars($row['email']); ?>"><?php echo htmlspecialchars($row['email']); ?></a></div>
                </div>

                <div class="detail-field">
                    <label class="detail-label">Type de problème</label>
                    <div class="detail-value"><?php echo htmlspecialchars($row['type']); ?></div>
                </div>

                <div class="detail-field">
                    <label class="detail-label">Description</label>
                    <div class="detail-value"><?php echo nl2br(htmlspecialchars($row['description'])); ?></div>
                </div>

                <div class="detail-field">
                    <label class="detail-label">Date de création</label>
                    <div class="detail-value"><?php echo htmlspecialchars($row['date_creation']); ?></div>
                </div>

                <div class="detail-field">
                    <label class="detail-label">Statut</label>
                    <div class="detail-value">
                        <span style="padding: 6px 12px; border-radius: 20px; background: <?php echo $row['statut'] == 'nouveau' ? '#FFF3CD' : ($row['statut'] == 'en_cours' ? '#D1ECF1' : '#D4EDDA'); ?>; color: <?php echo $row['statut'] == 'nouveau' ? '#856404' : ($row['statut'] == 'en_cours' ? '#0C5460' : '#155724'); ?>;">
                            <?php echo ucfirst(str_replace('_', ' ', htmlspecialchars($row['statut']))); ?>
                        </span>
                    </div>
                </div>

                <div class="action-buttons">
                    <a href="modifier_reclamation.php?id=<?php echo $row['id']; ?>" class="btn btn-primary"><i class="fa-solid fa-edit"></i> Modifier le statut</a>
                    <a href="gerer_reclamations.php" class="btn btn-secondary"><i class="fa-solid fa-arrow-left"></i> Retour</a>
                </div>
            </div>
        </main>
    </div>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
