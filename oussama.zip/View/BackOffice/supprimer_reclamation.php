<?php
// supprimer_reclamation.php
// Supprime une réclamation de manière sécurisée

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$database = "peacelink";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Erreur de connexion: " . htmlspecialchars($conn->connect_error));
}

// Vérifier si l'ID est fourni
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['message_error'] = "ID de réclamation manquant.";
    header("Location: gerer_reclamations.php");
    exit();
}

$id = intval($_GET['id']);

// Vérifier que la réclamation existe avant suppression
$check_sql = "SELECT id FROM reclamations WHERE id = ?";
$check_stmt = $conn->prepare($check_sql);
$check_stmt->bind_param("i", $id);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows === 0) {
    $_SESSION['message_error'] = "Réclamation non trouvée.";
    header("Location: gerer_reclamations.php");
    exit();
}
$check_stmt->close();

// Supprimer la réclamation
$sql = "DELETE FROM reclamations WHERE id = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    $_SESSION['message_error'] = "Erreur de préparation: " . htmlspecialchars($conn->error);
    header("Location: gerer_reclamations.php");
    exit();
}

$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    $_SESSION['message_success'] = "Réclamation supprimée avec succès.";
} else {
    $_SESSION['message_error'] = "Erreur lors de la suppression: " . htmlspecialchars($stmt->error);
}

$stmt->close();
$conn->close();

header("Location: gerer_reclamations.php");
exit();
?>
