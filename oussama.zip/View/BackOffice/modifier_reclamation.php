<?php
// modifier_reclamation.php
// Permet de modifier le statut d'une réclamation

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$database = "peacelink";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Erreur de connexion: " . $conn->connect_error);
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $statut = isset($_POST['statut']) ? trim($_POST['statut']) : '';
    
    if (empty($statut)) {
        $_SESSION['message_error'] = "Le statut est obligatoire.";
        header("Location: modifier_reclamation.php?id=$id");
        exit();
    }
    
    $sql = "UPDATE reclamations SET statut = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $statut, $id);
    
    if ($stmt->execute()) {
        $_SESSION['message_success'] = "Statut mis à jour avec succès.";
        header("Location: detail_reclamation.php?id=$id");
        exit();
    } else {
        $_SESSION['message_error'] = "Erreur lors de la mise à jour.";
    }
    $stmt->close();
}

// Récupérer la réclamation
$sql = "SELECT * FROM reclamations WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: gerer_reclamations.php");
    exit();
}

$row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier la réclamation - PeaceLink</title>
    <link rel="stylesheet" href="backofficeStyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .form-container { max-width: 600px; margin: 40px auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0px 2px 12px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 20px; display: flex; flex-direction: column; }
        .form-group label { font-weight: 600; margin-bottom: 8px; }
        .form-group select { padding: 12px; border: 1px solid #ccc; border-radius: 8px; font-size: 16px; }
        .form-actions { display: flex; gap: 10px; margin-top: 30px; }
        .btn { padding: 12px 20px; border-radius: 8px; cursor: pointer; font-weight: 600; border: none; }
        .btn-primary { background: #5DADE2; color: white; }
        .btn-secondary { background: #e9ecef; color: #333; }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <a href="#" class="logo">
                <img src="mon-logo.png" alt="Logo">
                <span>PeaceLink</span>
            </a>
        </div>
    </div>

    <div class="main-content">
        <header class="topbar">
            <h1 style="margin-left:20px;">Modifier le statut</h1>
        </header>

        <main class="content-wrapper">
            <div class="form-container">
                <h2>Réclamation #<?php echo htmlspecialchars($row['id']); ?> - <?php echo htmlspecialchars($row['nom']); ?></h2>
                <p style="color: #666; margin-top: 10px;">Changer le statut de cette réclamation</p>

                <form method="post">
                    <div class="form-group">
                        <label>Statut actuel: <strong><?php echo ucfirst(str_replace('_', ' ', htmlspecialchars($row['statut']))); ?></strong></label>
                    </div>

                    <div class="form-group">
                        <label for="statut">Nouveau statut</label>
                        <select id="statut" name="statut" required>
                            <option value="">-- Choisir un statut --</option>
                            <option value="nouveau" <?php echo $row['statut'] == 'nouveau' ? 'selected' : ''; ?>>Nouveau</option>
                            <option value="en_cours" <?php echo $row['statut'] == 'en_cours' ? 'selected' : ''; ?>>En cours</option>
                            <option value="resolu" <?php echo $row['statut'] == 'resolu' ? 'selected' : ''; ?>>Résolu</option>
                        </select>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save"></i> Enregistrer</button>
                        <a href="detail_reclamation.php?id=<?php echo $row['id']; ?>" class="btn btn-secondary"><i class="fa-solid fa-times"></i> Annuler</a>
                    </div>
                </form>
            </div>
        </main>
    </div>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
