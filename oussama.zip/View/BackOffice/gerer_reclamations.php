<?php
// gerer_reclamations.php
// Affiche toutes les réclamations et permet de les gérer

session_start();

// Configuration base de données
$servername = "localhost";
$username = "root";
$password = "";
$database = "peacelink";

// Créer la connexion
$conn = new mysqli($servername, $username, $password, $database);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Erreur de connexion: " . $conn->connect_error);
}

// Récupérer toutes les réclamations
$sql = "SELECT * FROM reclamations ORDER BY date_creation DESC";
$result = $conn->query($sql);

if (!$result) {
    die("Erreur dans la requête: " . $conn->error);
}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reclamations - PeaceLink</title>

    <link rel="stylesheet" href="backofficeStyle.css">
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>

    <!-- Sidebar identique -->
    <div class="sidebar">
        <div class="sidebar-header">
            <a href="#" class="logo">
                <img src="mon-logo.png" alt="Logo PeaceLink">
                <span>PeaceLink</span>
            </a>
        </div>

        <nav class="sidebar-nav">
            <a href="dashboard.html" class="nav-item">
                <i class="fa-solid fa-house"></i>
                <span>Dashboard</span>
            </a>

            <a href="stories.html" class="nav-item">
                <i class="fa-solid fa-book-open"></i>
                <span>Stories</span>
                <span class="badge orange">3</span>
            </a>

            <a href="gerer_reclamations.php" class="nav-item active">
                <i class="fa-solid fa-circle-exclamation"></i>
                <span>Reclamation</span>
                <span class="badge orange"><?php echo $result->num_rows; ?></span>
            </a>

            <a href="initiatives.html" class="nav-item">
                <i class="fa-solid fa-hand-holding-heart"></i>
                <span>Initiatives</span>
            </a>

            <a href="users.html" class="nav-item">
                <i class="fa-solid fa-users"></i>
                <span>Users</span>
            </a>
        </nav>

        <div class="sidebar-footer">
            <div class="user-profile">
                <i class="fa-solid fa-user-circle user-avatar"></i>
                <div class="user-info">
                    <span class="user-name">Admin User</span>
                    <span class="user-role">Administrator</span>
                </div>
            </div>
            <button class="logout-btn">
                <i class="fa-solid fa-right-from-bracket"></i>
            </button>
        </div>
    </div>

    <!-- Main content -->
    <div class="main-content">

        <header class="topbar">
            <h1 style="margin-left:20px;">Reclamations</h1>
        </header>

        <main class="content-wrapper">

            <div class="page-header">
                <div>
                    <h2>Liste des réclamations</h2>
                    <p class="page-subtitle">Gérer les réclamations des utilisateurs</p>
                </div>
            </div>

            <!-- Table des réclamations -->
            <div class="table-card">
                <h3>Toutes les réclamations</h3>

                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Utilisateur</th>
                                <th>Email</th>
                                <th>Type</th>
                                <th>Description</th>
                                <th>Date</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    // Déterminer la couleur du statut
                                    $statut_classe = 'nouveau';
                                    if ($row['statut'] == 'en_cours') {
                                        $statut_classe = 'en_cours';
                                    } elseif ($row['statut'] == 'resolu') {
                                        $statut_classe = 'resolu';
                                    }
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                                        <td><?php echo htmlspecialchars($row['nom']); ?></td>
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                                        <td><?php echo htmlspecialchars($row['type']); ?></td>
                                        <td><?php echo htmlspecialchars(substr($row['description'], 0, 50)) . "..."; ?></td>
                                        <td><?php echo htmlspecialchars($row['date_creation']); ?></td>
                                        <td><span class="statut-badge <?php echo $statut_classe; ?>"><?php echo ucfirst(str_replace('_', ' ', $row['statut'])); ?></span></td>
                                        <td class="actions-cell">
                                            <button class="action-btn" onclick="voirDetails(<?php echo $row['id']; ?>)">
                                                <i class="fa-solid fa-eye"></i>
                                            </button>
                                            <button class="action-btn" onclick="modifierStatut(<?php echo $row['id']; ?>)">
                                                <i class="fa-solid fa-pen"></i>
                                            </button>
                                            <button class="action-btn danger" onclick="supprimerReclamation(<?php echo $row['id']; ?>)">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                echo "<tr><td colspan='8' style='text-align: center;'>Aucune réclamation trouvée</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </main>

    </div>

    <script>
        function voirDetails(id) {
            window.location.href = 'detail_reclamation.php?id=' + id;
        }

        function modifierStatut(id) {
            window.location.href = 'modifier_reclamation.php?id=' + id;
        }

        function supprimerReclamation(id) {
            if (confirm('Êtes-vous sûr de vouloir supprimer cette réclamation?')) {
                window.location.href = 'supprimer_reclamation.php?id=' + id;
            }
        }
    </script>

</body>
</html>

<?php
$conn->close();
?>
